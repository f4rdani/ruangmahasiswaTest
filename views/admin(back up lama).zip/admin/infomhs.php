<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">						
						<div class="p-20">
                            <h4 class="card-title">pengumuman bagian depan</h4>
                                <form class="form-material m-t-40" method="post" action="<?php echo site_url('admin/store1'); ?>" enctype="multipart/form-data">
									<div class="form-group">
										<label>Announce_title</label>
										<input type="text" class="form-control form-control-line" name="judul" placeholder="Some text value..." required>
									</div>
									<div class="form-group">
										<label>Announce_story</label>
										<input type="text" class="form-control form-control-line" name="story"  placeholder="Some text value...">
									</div>
									<div class="form-group">
										<label>Waktu Pembukaan:</label>
										<input type="date" name="date" class="form-control form-control-line"  value="" required>
									</div>
									<div class="form-group">
										<label>file_pisik</label>
										<div class="fileinput fileinput-new input-group" data-provides="fileinput">
											<div class="form-control" data-trigger="fileinput">
												<i class="glyphicon glyphicon-file fileinput-exists"></i>
												<span class="fileinput-filename"></span>
											</div>
											<span class="input-group-append btn btn-default btn-file">
												<span class="fileinput-new">Select file</span>
												<span class="fileinput-exists">Change</span>
												<input type="file" name="file" accept=".pdf">
											</span>
											<a href="javascript:void(0)" class="input-group-append btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a>
										</div>
									</div>
									<input type="submit" class="btn btn-primary btn-user" value="Simpan">
								</form>
                        </div>
						<hr>
						<div class="card-body">
                                <h4 class="card-title">Data pengumuman</h4>
                               
                                <div class="table-responsive m-t-40">
                                    <table id="example231" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>title</th>
                                                <th>story</th>
                                                <th>show</th>
                                                <th>upload_by</th>
                                                <th>file_name</th>
                                                <th>date</th>
                                                <th>option</th>
                                            </tr>
                                        </thead>
                                        <tbody>
											<?php 
											$counter = 0;
											foreach($data as $date): 
											$counter++;
											?>
                                            <tr>
                                                <td><?= $counter ?></td>
                                                <td><?= $date->Announce_title ?></td>
                                                <td><?= $date->Announce_story ?></td>
                                                <td><?= $date->showed ?></td>
                                                <td><?= $date->nip ?></td>
                                                <td><?= $date->file_pisik ?></td>
                                                <td><?= $date->Announce_date ?></td>
												<td class="text-center">
                                                        <a data-toggle="modal" data-target="#myModal<?= $date->id?>" class=" btn
															btn-sm btn-danger"> Hapus</a>
														<a data-toggle="modal" data-target="#myModal1<?= $date->id?>" class=" btn
															btn-sm btn-info"> Edit</a>
														<a href="<?= base_url('assets/uploads/' . $date->file_pisik) ?>" class=" btn
															btn-sm btn-primary">view</a>
                                                </td>
												</tr>
												
												<!-- Modal Edit -->
												<div class="modal fade" id="myModal1<?= $date->id?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
													<div class="modal-dialog">
														<div class="modal-content">
															<div class="modal-header">
																<h4 class="modal-title" id="myModalLabel1">Edit Pengumuman</h4>
																<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
															</div>
															<div class="modal-body">
																<form method="post" action="<?= base_url('admin/editindexmhs/' . $date->id) ?>" enctype="multipart/form-data">
																	<div class="form-group">
																		<label>Announce_title</label>
																		<input type="text" class="form-control form-control-line" name="judul" value="<?= $date->Announce_title?>" required>
																	</div>
																	<div class="form-group">
																		<label>Announce_story</label>
																		<input type="text" class="form-control form-control-line" name="story"  value="<?= $date->Announce_story?>">
																	</div>
																	<div class="form-group">
																		<label>Waktu Pembukaan:</label>
																		<input type="date" name="date" class="form-control form-control-line"  value="<?= $date->Announce_date?>" required>
																	</div>
																	<div class="form-group">
																		<label>file_pisik</label>
																		<div class="fileinput fileinput-new input-group" data-provides="fileinput">
																			<div class="form-control" data-trigger="fileinput">
																				<i class="glyphicon glyphicon-file fileinput-exists"></i>
																				<span class="fileinput-filename"></span>
																			</div>
																			<span class="input-group-append btn btn-default btn-file">
																				<span class="fileinput-new">Select file</span>
																				<span class="fileinput-exists">Change</span>
																				<input type="file" name="file" accept=".pdf">
																			</span>
																			<a href="javascript:void(0)" class="input-group-append btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a>
																		</div>
																	</div>
																	<input type="hidden" name="id" value="">
																	<input type="submit" class="btn btn-primary btn-user" value="Simpan">
																</form>
															</div>
															<div class="modal-footer">
																<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
															</div>
														</div>
														<!-- /.modal-content -->
													</div>
													<!-- /.modal-dialog -->
												</div>
												<!-- /.modal -->


												<div id="myModal<?= $date->id?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
												    <div class="modal-dialog">
												        <div class="modal-content">
												            <div class="modal-header">
												                <h4 class="modal-title" id="myModalLabel">Konfirmasi Hapus Pengumuman</h4>
												                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
												            </div>
												            <div class="modal-body">
												                Anda yakin ingin menghapus pengumuman tersebut?
												            </div>
												            <div class="modal-footer">
												                <a href="<?= base_url('admin/hapusindexmhs/' . $date->id) ?>"
												                    class="btn btn-danger waves-effect waves-light style=" margin-right:30px">HAPUS</a>
												                <button type=" button" class="btn btn-info waves-effect" data-dismiss="modal">Close</button>
												            </div>
												        </div>
												        <!-- /.modal-content -->
												    </div>

												    <!-- /.modal-dialog -->
												</div>
											<?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                    </div>
			</div>
		</div>
	</div>
</div>
