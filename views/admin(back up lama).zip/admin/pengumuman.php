<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#home" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span> <span class="hidden-xs-down">Tabel Pengumuman</span></a> </li>
                    <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#profile" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Tabel text jalan</span></a> </li>
                    <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#messages" role="tab"><span class="hidden-sm-up"><i class="ti-email"></i></span> <span class="hidden-xs-down">Messages</span></a> </li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content tabcontent-border">
                    <div class="tab-pane active" id="home" role="tabpanel">
                        <div class="p-20">
                            <h4 class="card-title">pengumuman bagian depan</h4>
                                <form class="form-material m-t-40" method="post" action="<?php echo site_url('admin/store'); ?>" enctype="multipart/form-data">
									<div class="form-group">
										<label>Judul</label>
										<input type="text" class="form-control form-control-line" name="judul" placeholder="Some text value..." required>
									</div>
									<div class="form-group">
										<label>File upload</label>
										<div class="fileinput fileinput-new input-group" data-provides="fileinput">
											<div class="form-control" data-trigger="fileinput">
												<i class="glyphicon glyphicon-file fileinput-exists"></i>
												<span class="fileinput-filename"></span>
											</div>
											<span class="input-group-append btn btn-default btn-file">
												<span class="fileinput-new">Select file</span>
												<span class="fileinput-exists">Change</span>
												<input type="file" name="file" accept=".pdf">
											</span>
											<a href="javascript:void(0)" class="input-group-append btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a>
										</div>
									</div>
									<input type="submit" class="btn btn-primary btn-user" value="Simpan">
								</form>
                        </div>
						<hr>
						<div class="card-body">
                                <h4 class="card-title">Data pengumuman</h4>
                               
                                <div class="table-responsive m-t-40">
                                    <table id="example231" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>id</th>
                                                <th>title</th>
                                                <th>upload_by</th>
                                                <th>file_name</th>
                                                <th>date</th>
                                                <th>option</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php 
$counter = 0;
foreach($data as $date): 
    $counter++;
?>
    <tr>
        <td><?= $counter ?></td>
        <td><?= $date->id ?></td>
        <td><?= $date->judul ?></td>
        <td><?= $date->user_upload ?></td>
        <td><?= $date->file ?></td>
        <td><?= $date->tgl_update ?></td>
        <td class="text-center">
            <a data-toggle="modal" data-target="#myModalhapus<?= $date->id ?>" class="btn btn-sm btn-danger"> Hapus</a>
            <a data-toggle="modal" data-target="#myModaledit<?= $date->id ?>" class="btn btn-sm btn-info"> Edit</a>
            <a href="<?= base_url('assets/uploads/' . $date->file) ?>" class="btn btn-sm btn-primary">view</a>
        </td>
    </tr>
											  <!-- Modal for each row -->
    <div id="myModalhapus<?= $date->id ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel">Konfirmasi Hapus Pengumuman</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">
                    Anda yakin ingin menghapus pengumuman tersebut?
                    ID: <?= $date->id ?>
                </div>
                <div class="modal-footer">
                    <a href="<?= base_url('admin/hapuspost/' . $date->id) ?>"
                        class="btn btn-danger waves-effect waves-light" style="margin-right:30px">HAPUS</a>
                    <button type="button" class="btn btn-info waves-effect" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div id="myModaledit<?= $date->id ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="card-body">
                <h4 class="card-title">Edit Pengumuman Bagian Depan</h4>
                <form class="form-material m-t-40" method="post" action="<?php echo site_url('admin/edit/'.$date->id); ?>" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $date->id; ?>" />
                    <div class="form-group">
                        <label>Judul</label>
                        <input type="text" class="form-control form-control-line" name="judul" value="Some text value..." required>
                    </div>
                    <div class="form-group">
                        <label>File Upload</label>
                        <div class="fileinput fileinput-new input-group" data-provides="fileinput">
                            <div class="form-control" data-trigger="fileinput">
                                <i class="glyphicon glyphicon-file fileinput-exists"></i>
                                <span class="fileinput-filename"></span>
                            </div>
                            <span class="input-group-append btn btn-default btn-file">
                                <span class="fileinput-new">Select file</span>
                                <span class="fileinput-exists">Change</span>
                                <input type="file" name="file" accept=".pdf">
                            </span>
                            <a href="javascript:void(0)" class="input-group-append btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a>
                        </div>
                    </div>
                    <input type="submit" class="btn btn-primary btn-user" value="Simpan">
                </form>
            </div>
        </div>
    </div>
</div>

<?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                    </div>
                    <div class="tab-pane  p-20" id="profile" role="tabpanel">

						<h4 class="card-title">pengumuman text jalan</h4>
                                <form class="form-material m-t-40" method="post" action="<?php echo site_url('admin/storejln'); ?>" enctype="multipart/form-data">
									<div class="form-group">
										<label>Judul</label>
										<input type="text" class="form-control form-control-line" name="judul" placeholder="Some text value..." required>
									</div>
									<div class="form-group">
                                    <label>Isi pengumuman</label>
                                    <input type="text" class="form-control form-control-line" name="isi_pengumuman" placeholder="Some text value..." required>
									</div>
									<input type="submit" class="btn btn-primary btn-user" value="Simpan">
								</form>		
								<br>
								<hr>	
								<br>			
							<h4 class="card-title">Data pengumuman</h4>
                               
                                <div class="table-responsive m-t-40">
                                    <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>title</th>
                                                <th>upload_by</th>
                                                <th>Isi pengumuman</th>
                                                <th>date</th>
                                                <th>option</th>
                                            </tr>
                                        </thead>
                                        <tbody>
											<?php 
											$counter = 0;
											foreach($dat as $p): 
											$counter++;
											?>
                                            <tr>
                                                <td><?= $counter ?></td>
                                                <td><?= $p->judul ?></td>
                                                <td><?= $p->petugas ?></td>
                                                <td><?= $p->isi_pengumuman ?></td>
                                                <td><?= $p->tanggal ?></td>
												<td class="text-center">
                                                        <a data-toggle="modal" data-target="#myModaljln1<?= $p->id_pengumuman ?>" class=" btn
															btn-sm btn-danger"> Hapus</a>
														<a data-toggle="modal" data-target="#myModaljln<?= $p->id_pengumuman ?>" class=" btn
															btn-sm btn-info"> Edit</a>
                                                </td>
                                            </tr>
                                             <!-- /.modal-dialog -->
    <div id="myModaljln<?= $p->id_pengumuman ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="card-body">
                    <h4 class="card-title">Edit Pengumuman Jalan</h4>
                <form class="form-material m-t-40" method="post" action="<?php echo site_url('admin/editjln/'.$p->id_pengumuman); ?>" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $p->id_pengumuman; ?>" />
                    <div class="form-group">
                        <label>Judul</label>
                        <input type="text" class="form-control form-control-line" name="judul" value="<?= $p->judul ?>" required>
                    </div>
                    <div class="form-group">
                    <label>Isi Pengumuman</label>
                    <input type="text" class="form-control form-control-line" name="isi_pengumuman" value="<?= $p->isi_pengumuman ?>" required>
                    </div>
                    <input type="submit" class="btn btn-primary btn-user" value="Simpan">
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<div id="myModaljln1<?= $p->id_pengumuman ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Konfirmasi Hapus Pengumuman</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                Anda yakin ingin menghapus pengumuman tersebut?
                <?= $p->id_pengumuman ?>
            </div>
            <div class="modal-footer">
                <a href="<?= base_url('admin/hapuspostjln/' . $p->id_pengumuman) ?>"
                    class="btn btn-danger waves-effect waves-light style=" margin-right:30px">HAPUS</a>
                <button type=" button" class="btn btn-info waves-effect" data-dismiss="modal">Close</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
</div>
											 <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
					</div>
                    <div class="tab-pane p-20" id="messages" role="tabpanel">3</div>
                </div>
            </div>
        </div>
    </div>
                                            <!--MODAL -->
</div>

   
